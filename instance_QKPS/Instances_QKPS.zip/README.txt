First line: File Name
Second Line: Number of items: n
Third line: Linear profits: p_i (i = 1, ..., n)
Triangular matrix: Quadratic profits: for each row (item) i (i = 1, ..., n-1): p_{i,j} (j = i+1, ..., n)  
                   (see original format qkp: https://cedric.cnam.fr/~soutif/QKP/)
Next Line: Empty space
Next Line: Value "0"
Next Line: Knapsack capacity: c
Next Line: Weights of the items: w_i (i = 1, ..., n)
Next line: Value of "e" (uniformly random number in [0.15,0.25])
Next line: Number of different "partitions" of the n items into r classes (for the current experiments there are 3 "partitions" with r={2,5,10}).
Next Line: Empty space
For each "partition":
* First line: r (number of classes, r can be 2, 5 and 10)
* Next line: Number of items for each class (equal to n/r).
* Next line: class of each item i (i = 1, ..., n) (integer value between 0 and r-1).
* Next line: Values of f_h (h = 0, ..., r-1): activation setup cost of class h
* Next line: Values of d_h (h = 0, ..., r-1): activation setup reduction of class h
* Next line: Empty space